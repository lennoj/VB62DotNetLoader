﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;
using NPOI.SS.UserModel;
using NPOI.Util;
using NPOI.Util.Collections;
using NPOI.HSSF;
using NPOI.HSSF.UserModel;
using NPOI.HSSF.Util;
using NPOI.XSSF;
using NPOI.XSSF.UserModel;
using NPOI.XSSF.Util;
using NPOI.POIFS;
using NPOI.HPSF;
using NPOI.DDF;
using NPOI.OpenXml4Net.Util;
using NPOI.OpenXmlFormats.Spreadsheet;
using NPOI.WP.UserModel;

namespace AlphaList.Classes
{
    public class ExcelFactory
    {
        public delegate bool DELReadSheetRowByRow(ISheet targetSheet, IRow currentRow, IRow lastRow , int currentRowIndex, int lastRowIndex);
        public static IWorkbook OpenWorkBook(string WorkBookFilePath) 
        {
            IWorkbook __OpenWorkBook = null;

            try
            {
                // Check if file exist
                if (!File.Exists(WorkBookFilePath))
                    return null;
                                

                // File exist
                // Check if xls or xlsx
                FileInfo __WBInfo = new FileInfo(WorkBookFilePath);
                if (__WBInfo.Extension.Equals(".xls"))
                {

                    __OpenWorkBook = WorkbookFactory.Create(WorkBookFilePath);
                    return __OpenWorkBook;
                }
                else if (__WBInfo.Extension.Equals(".xlsx"))
                {
                    __OpenWorkBook = WorkbookFactory.Create(WorkBookFilePath);
                    return __OpenWorkBook;
               
                }
                else if (__WBInfo.Extension.Equals(".xlsm"))
                {
                    __OpenWorkBook = WorkbookFactory.Create(WorkBookFilePath);
                    return __OpenWorkBook;
               
                }
                else
                    return null;

            }
            catch (Exception OpenWBException)
            {
                Console.WriteLine(OpenWBException.Message);
                Console.WriteLine(OpenWBException.StackTrace);
                return null;
            }
            
        }

        public static ISheet OpenSheet(IWorkbook OpenedWorkBook, string SheetName) 
        {
            ISheet __OpenSheet = null;

            try
            {
                __OpenSheet = OpenedWorkBook.GetSheet(SheetName);
                return __OpenSheet;
            }
            catch (Exception ex)
            {         
                Console.WriteLine(ex.Message);
                Console.WriteLine(ex.StackTrace);                        
                return null;
            }
            
        }


        public static void ReadSheetRowByRow(ISheet sheet,DELReadSheetRowByRow readCallBack , DELReadSheetRowByRow shouldReadCallBack) 
        {
            int? currentRowIndex = null;
            int? lastRowIndex = null;
            IRow currentRow = null;
            IRow lastRow = null;

            currentRowIndex = sheet.FirstRowNum;
            lastRowIndex = sheet.LastRowNum;
                
            while (currentRowIndex <= lastRowIndex)
            {
                currentRow = sheet.GetRow((int)currentRowIndex);
                lastRow = sheet.GetRow((int)lastRowIndex);

                if (shouldReadCallBack != null)
                {
                    if (shouldReadCallBack(sheet, currentRow, lastRow, (int)currentRowIndex, (int)lastRowIndex))
                        readCallBack(sheet, currentRow, lastRow, (int)currentRowIndex, (int)lastRowIndex); 
                }
                else readCallBack(sheet, currentRow, lastRow, (int)currentRowIndex, (int)lastRowIndex);
                   
                currentRowIndex++;
            }
        }
 
    }
}
