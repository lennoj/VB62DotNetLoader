﻿namespace EkoopBanker.CIC.UI
{
    partial class ProgressDialogBox
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(ProgressDialogBox));
            this.LBLProgress = new System.Windows.Forms.Label();
            this.LBLStatus = new System.Windows.Forms.Label();
            this.MainProgressBar = new System.Windows.Forms.Panel();
            this.LBLElapseTime = new System.Windows.Forms.Label();
            this.BTNEventState = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // LBLProgress
            // 
            this.LBLProgress.Location = new System.Drawing.Point(-1, 33);
            this.LBLProgress.Name = "LBLProgress";
            this.LBLProgress.Size = new System.Drawing.Size(708, 20);
            this.LBLProgress.TabIndex = 2;
            this.LBLProgress.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // LBLStatus
            // 
            this.LBLStatus.Location = new System.Drawing.Point(-1, 13);
            this.LBLStatus.Name = "LBLStatus";
            this.LBLStatus.Size = new System.Drawing.Size(708, 20);
            this.LBLStatus.TabIndex = 3;
            this.LBLStatus.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // MainProgressBar
            // 
            this.MainProgressBar.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.MainProgressBar.Location = new System.Drawing.Point(12, 88);
            this.MainProgressBar.MaximumSize = new System.Drawing.Size(682, 20);
            this.MainProgressBar.Name = "MainProgressBar";
            this.MainProgressBar.Size = new System.Drawing.Size(682, 20);
            this.MainProgressBar.TabIndex = 4;
            // 
            // LBLElapseTime
            // 
            this.LBLElapseTime.Location = new System.Drawing.Point(12, 59);
            this.LBLElapseTime.Name = "LBLElapseTime";
            this.LBLElapseTime.Size = new System.Drawing.Size(682, 20);
            this.LBLElapseTime.TabIndex = 5;
            this.LBLElapseTime.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // BTNEventState
            // 
            this.BTNEventState.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.BTNEventState.Location = new System.Drawing.Point(590, 125);
            this.BTNEventState.Name = "BTNEventState";
            this.BTNEventState.Size = new System.Drawing.Size(104, 32);
            this.BTNEventState.TabIndex = 6;
            this.BTNEventState.Text = "Pause";
            this.BTNEventState.UseVisualStyleBackColor = true;
            this.BTNEventState.Click += new System.EventHandler(this.BTNEventState_Click);
            // 
            // ProgressDialogBox
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 14F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Black;
            this.ClientSize = new System.Drawing.Size(705, 115);
            this.Controls.Add(this.BTNEventState);
            this.Controls.Add(this.LBLElapseTime);
            this.Controls.Add(this.MainProgressBar);
            this.Controls.Add(this.LBLStatus);
            this.Controls.Add(this.LBLProgress);
            this.Font = new System.Drawing.Font("Calibri", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ForeColor = System.Drawing.Color.White;
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "ProgressDialogBox";
            this.ShowInTaskbar = false;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.TopMost = true;
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.ProgressDialogBox_FormClosing);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Label LBLProgress;
        private System.Windows.Forms.Label LBLStatus;
        private System.Windows.Forms.Panel MainProgressBar;
        private System.Windows.Forms.Label LBLElapseTime;
        private System.Windows.Forms.Button BTNEventState;
    }
}