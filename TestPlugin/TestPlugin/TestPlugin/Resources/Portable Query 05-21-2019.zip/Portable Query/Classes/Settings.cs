﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;


namespace Portable_Query.Classes
{
    public class Settings
    {
        private string SettingHeader;
        private string SettingName;
        private string SettingPath;
        private string SettingVersion;
        
        private Dictionary<string, string> Data;

        protected Settings(string SettingHeader, string SettingName, string SettingPath, string SettingVersion , Dictionary<string,string> LoadedData)
        {
            this.Data = LoadedData;
            this.SettingHeader = SettingHeader;
            this.SettingName = SettingName;
            this.SettingPath = SettingPath;
            this.SettingVersion = SettingVersion;
        }

        public string this[string key]
        {
            get
            {
                return Data[key];  
            } 
        }

        public static Settings CreateSettings(string SettingHeader, string SettingName, string SettingPath, string SettingVersion , Dictionary<string,string> Data) 
        {
            // Create the header of the file
            string _HEADER = SettingHeader.Replace(" ", "_") + @"\;\" + SettingName + @"\;\" + SettingVersion;
            string _ITEM_COUNT = "Data Count:" + Data.Count;
            byte[] _token = null;

            try
            {
                FileStream cFstream = new FileStream(SettingPath, FileMode.Create , FileAccess.Write , FileShare.None);
                BinaryWriter cBwriter = new BinaryWriter(cFstream);

                // Write the header
                _token = Flip(_HEADER + "\n");
                cBwriter.Write(_token, 0, _token.Length);
                _token = Flip(_ITEM_COUNT + "\n");
                cBwriter.Write(_token, 0, _token.Length);


                foreach (String cKey in Data.Keys)
                {
                     _token = Flip(cKey + @"\;\" + Data[cKey] + "\n");
                    cBwriter.Write(_token, 0, _token.Length);
                }

                cBwriter.Close();
                cFstream.Close();
            }
            catch (Exception Ex)
            {
                LocalLogger.WriteLog(Ex.Message, LocalLogger.ApplicationLogs, true);
                LocalLogger.WriteLog(Ex.StackTrace, LocalLogger.ApplicationLogs, true);
            }

            return new Settings(SettingHeader, SettingName, SettingPath, SettingVersion, Data);
        }



        public static Settings LoadSettings(string SettingPath, string SettingVersion)
        {
            try
            {
                Dictionary<string, string> Data = new Dictionary<string, string>();
                FileStream cFstream = new FileStream(SettingPath, FileMode.Open, FileAccess.Read, FileShare.None);
                BinaryReader cBreader = new BinaryReader(cFstream);
                int len = 0;
                byte[] buffer = new byte[1024];
                string read_data = "";
                string[] tokens = null;

                while((len = cBreader.Read(buffer, 0, ((int)cFstream.Length > buffer.Length ? buffer.Length : (int)cFstream.Length) )) > 0)
                {
                    foreach (byte bt in buffer)
                    {
                        if(bt > 0 )
                        read_data += (char)bt;
                    }
                }

                buffer = Flip(read_data);

                read_data = ToText(buffer);

                tokens = read_data.Split('\n');

                // Get the header information
                string[] _header_tokens = tokens[0].Replace(@"\;\" , "\t").Split('\t');

                // Check if correct version
                if (!_header_tokens[2].Equals(SettingVersion))
                    throw new Exception("Setting version mismatch!" + Environment.NewLine + "Required version: " + _header_tokens[3]);

                for (int i = 2; i < tokens.Length; i++)
                {
                    if (tokens[i].Length > 0)
                    {
                        string[] param_tokens = tokens[i].Replace(@"\;\", "\t").Split('\t');
                        if (param_tokens.Length == 2)
                            Data.Add(param_tokens[0], param_tokens[1]);
                    }
                }


                cBreader.Close();
                cFstream.Close();

                return new Settings(_header_tokens[0], _header_tokens[1], SettingPath, _header_tokens[2], Data);
            }
            catch (Exception Ex)
            {
                LocalLogger.WriteLog(Ex.Message, LocalLogger.ApplicationLogs, true);
                LocalLogger.WriteLog(Ex.StackTrace, LocalLogger.ApplicationLogs, true);
            }
            return null;
        }

        public static void WriteEncryptedFile(string SettingPath,string Data) 
        {
            try
            {
                FileStream cFstream = new FileStream(SettingPath, FileMode.Create, FileAccess.Write, FileShare.None);
                BinaryWriter cBwriter = new BinaryWriter(cFstream);
                byte[] buffer = new byte[Data.Length];

                buffer = Flip(Data);
                cBwriter.Write(buffer, 0, buffer.Length);
            }
            catch (Exception Ex)
            {
                LocalLogger.WriteLog(Ex.Message, LocalLogger.ApplicationLogs, true);
                LocalLogger.WriteLog(Ex.StackTrace, LocalLogger.ApplicationLogs, true);
            }

        }

        public static string ReadEncryptedFile(string SettingPath)
        {
            try
            {
                FileStream cFstream = new FileStream(SettingPath, FileMode.Open, FileAccess.Read, FileShare.None);
                BinaryReader cBreader = new BinaryReader(cFstream);
                string read_data = "";
                int len = 0;
                byte[] buffer = new byte[1024];
                while (true)
                {
                    len = cBreader.Read(buffer, 0, buffer.Length);
                    if (len <= 0) break;
                    for (int i = 0; i < len; i++)
                    {
                        read_data += (char)buffer[i];
                    }

                   
                }

                read_data = ToText(Flip(read_data));
                return read_data;
            }
            catch (Exception Ex)
            {
                LocalLogger.WriteLog(Ex.Message, LocalLogger.ApplicationLogs, true);
                LocalLogger.WriteLog(Ex.StackTrace, LocalLogger.ApplicationLogs, true);
            }

            return "";
        }

        private static byte[] Flip(string Data) 
        {
            byte[] buffer = ToBytes(Data);

            for (int i = 0; i < buffer.Length; i++)
            {
                buffer[i] = (byte)((byte)buffer[i] ^ (byte)128);
            }

            return buffer;
        }

        private static byte[] ToBytes(string data)
        {
            byte[] buffer = new byte[data.Length];

            for (int i = 0; i < data.Length; i++)
            {
                buffer[i] = (byte)data[i];
            }

            return buffer;
        }

        private static string ToText(byte[] data)
        {
            string buffer = "";

            for (int i = 0; i < data.Length; i++)
            {
                buffer += (char)data[i];
            }

            return buffer;
        }

        
    }
}
