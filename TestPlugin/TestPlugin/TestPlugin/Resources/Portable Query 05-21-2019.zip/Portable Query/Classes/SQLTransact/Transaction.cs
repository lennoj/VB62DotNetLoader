﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data.Sql;
using System.Data.SqlClient;
using System.Data.SqlTypes;
using Portable_Query.Classes;

namespace Portable_Query.Classes.SQLTransact
{
    public sealed class Transaction
    {
        private SqlConnection _Connection;
        private SqlCommand _Command;
        private ITransaction _Transaction;
        private Exception _Exception;
        

        public SqlConnection Connection { get { return this._Connection; } }
        public SqlCommand Command { get { return this._Command; } }
        public Exception LastError { get { return this._Exception; } }

        public Transaction(SqlConnection connection, ITransaction transaction) 
        {
            this._Connection = connection;
            this._Command = connection == null ? null : connection.CreateCommand();
            this._Transaction = transaction;
        }

        public Transaction(SqlConnection connection, ITransaction transaction , Exception Error)
        {
            this._Connection = connection;
            this._Command = connection == null ? null : connection.CreateCommand();
            this._Transaction = transaction;
            this._Exception = Error;
        }
    
    
        #region ITransaction Members

        public Transaction Reset() 
        {
            this._Command.Dispose();
            if (this._Connection.State == System.Data.ConnectionState.Closed) 
                this._Connection.Open();

            this._Command = this._Connection.CreateCommand();
            this._Command.CommandText = "";

            return this;
        }

        public Transaction Begin()
        {
            if (this._Connection == null)
                if (this._Transaction != null)
                {
                    this._Transaction.ErrorTransaction(this);
                    return this;
                }

            try
            {
                if (this._Transaction != null)
                {
                    if (this.Connection.State != System.Data.ConnectionState.Open)
                    {
                        this.Connection.Open();
                    }

                    this._Command = this._Connection.CreateCommand();

                    this._Transaction.BeginTransaction(this);
                }

                return this;
            }
            catch (Exception ex)
            {
                if (this._Transaction != null)
                {
                    LocalLogger.WriteLog("Error Occured", LocalLogger.ErrorLogs, true);
                    LocalLogger.WriteLog(ex.Message, LocalLogger.ErrorLogs, true);
                    LocalLogger.WriteLog(ex.StackTrace, LocalLogger.ErrorLogs, true);

                    this._Exception = ex;
                    this._Transaction.ErrorTransaction(this);
                }

                return this;
            }
        }

        public Transaction Transact()
        {
            if (this._Connection == null)
                if (this._Transaction != null)
                {
                    this._Transaction.ErrorTransaction(this);
                    return this;
                }

            try
            {
                if (this._Transaction != null)
                {
                    if (this.Connection.State != System.Data.ConnectionState.Open)
                    {
                        this.Connection.Open();
                    }
                    this.Command.Connection = this.Connection;

                    this._Transaction.Transact(this);

                    if (this.Connection.State != System.Data.ConnectionState.Open)
                    {
                        this.Connection.Open();
                    }

                    this._Command = this._Connection.CreateCommand();
                    this._Command.Parameters.Clear();
                    
                }

                return this;
            }
            catch (Exception ex)
            {
                if (this._Transaction != null)
                {
                    LocalLogger.WriteLog("Error Occured", LocalLogger.ErrorLogs, true);
                    LocalLogger.WriteLog(ex.Message, LocalLogger.ErrorLogs, true);
                    LocalLogger.WriteLog(ex.StackTrace, LocalLogger.ErrorLogs, true);

                    this._Exception = ex;
                    this._Transaction.ErrorTransaction(this);
                }

                return this;
            }
        }


        public Transaction  End()
        {
            if (this._Connection == null)
                if (this._Transaction != null)
                {
                    this._Transaction.ErrorTransaction(this);
                    return this;
                }

            try
            {
                if (this._Transaction != null)
                {
                    if (this.Connection.State != System.Data.ConnectionState.Open)
                    {
                        this.Connection.Open();
                    }
                    this._Command = this._Connection.CreateCommand();
                    
                    this._Transaction.EndTransaction(this);

                    this._Connection.Close();
                }
                return this;
            }
            catch (Exception ex)
            {
                if (this._Transaction != null)
                {
                    LocalLogger.WriteLog("Error Occured", LocalLogger.ErrorLogs, true);
                    LocalLogger.WriteLog(ex.Message, LocalLogger.ErrorLogs, true);
                    LocalLogger.WriteLog(ex.StackTrace, LocalLogger.ErrorLogs, true);

                    this._Exception = ex;
                    this._Transaction.ErrorTransaction(this);
                }

                return this;
            }
        }
        #endregion

    }
}
