﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data.Sql;
using System.Data.SqlClient;
using System.Data.SqlTypes;

namespace Portable_Query.Classes.SQLTransact
{
    /// <summary>
    /// SQLTransaction : Use to call object that inherits ITransaction and return an ojbect of Transaction for chain calls
    /// JPMendoza 05-02-2019
    /// </summary>
    public abstract class SQLTransaction
    {
        private static string _connectionString;
        public static string ConnectionString { get { return SQLTransaction._connectionString;  } }

        private SQLTransaction() 
        {
            
        }

        public static Transaction CreateTransaction(string ConnectionString , ITransaction iTransaction) 
        {
            try
            {
                SQLTransaction._connectionString = ConnectionString;
                SqlConnection _NewConnection = new SqlConnection(ConnectionString);
                _NewConnection.Open();

                Transaction _NewTransaction = new Transaction(_NewConnection, iTransaction);


                return _NewTransaction;
            }
            catch (Exception ExError)
            {
                Transaction errTran = new Transaction(null, iTransaction, ExError);
                return errTran;
            }
            
        }

        public static Transaction CreateTransaction(string host , string username, string password , string initialCatalog, ITransaction iTransaction)
        {
            try
            {
                SqlConnectionStringBuilder conBuilder = new SqlConnectionStringBuilder();
                conBuilder.DataSource = host;
                conBuilder.UserID = username;
                conBuilder.Password = password;
                conBuilder.InitialCatalog = initialCatalog;

                SQLTransaction._connectionString = conBuilder.ConnectionString; ;
                SqlConnection _NewConnection = new SqlConnection(ConnectionString);
                _NewConnection.Open();

                Transaction _NewTransaction = new Transaction(_NewConnection, iTransaction);


                return _NewTransaction;
            }
            catch (Exception ExError)
            {
                Transaction errTran = new Transaction(null, iTransaction, ExError);
                return errTran;
            }

        }

      
    }
}
