﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data.Sql;
using System.Data.SqlClient;
using System.Data.SqlTypes;

namespace Portable_Query.Classes.SQLTransact
{
    /// <summary>
    /// ITransaction : Base Interface to inherit to encapsulate SQL Transaction
    /// JPMendoza 05-02-2019
    /// </summary>
    public interface ITransaction
    {
        Transaction BeginTransaction(Transaction transaction);
        Transaction EndTransaction(Transaction transaction);
        Transaction Transact(Transaction transaction);
        Transaction ErrorTransaction(Transaction transaction);
    }
}
