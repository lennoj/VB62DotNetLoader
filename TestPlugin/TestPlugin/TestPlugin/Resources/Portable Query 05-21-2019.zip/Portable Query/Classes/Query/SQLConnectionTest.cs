﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Portable_Query.Classes;
using Portable_Query.Classes.SQLTransact;
using Portable_Query.Forms;
using System.Windows.Forms;
using System.Data;
using System.Data.Sql;
using System.Data.SqlClient;
using System.Data.SqlTypes;
using System.IO;

namespace Portable_Query.Classes.Query
{
    public class SQLConnectionTest : ITransaction
    {
        private Form View;
        private Settings Settings;
        private bool IsTest;

        public SQLConnectionTest(Form View , Settings setting , bool isTest)
        {
            this.View = View;
            this.Settings = setting;
            this.IsTest = isTest;
        }

        #region ITransaction Members

        public Transaction BeginTransaction(Transaction transaction)
        {
            transaction.Reset();
            if(((FormConnectionSettings)this.View).TXTInitialCatalog.Text.Length > 0)
            {
                transaction.Command.CommandText = "SELECT name FROM sys.databases WHERE name=@dbname";
                transaction.Command.CommandType = System.Data.CommandType.Text;
                transaction.Command.Parameters.AddWithValue("@dbname", ((FormConnectionSettings)this.View).TXTInitialCatalog.Text);
                SqlDataAdapter da = new SqlDataAdapter(transaction.Command);
                DataSet ds = new DataSet();
                da.Fill(ds);

                if (ds.Tables.Count > 0)
                    if (ds.Tables[0].Rows.Count == 0)
                    {
                        MessageBox.Show(this.View, "Initial Catalog not found!", "Connection Test", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                        return transaction;
                    }
            }

            MessageBox.Show(this.View, "Connection established!", "Connection Test", MessageBoxButtons.OK, MessageBoxIcon.Information);

            string ConnectionSettings = new FileInfo(Application.ExecutablePath).Directory.FullName + @"\ConnectionSettings.stg";
            Dictionary<string, string> Data = new Dictionary<string, string>();
            Data.Add("SQLHost", ((FormConnectionSettings)this.View).TXTHost.Text);
            Data.Add("SQLUsername", ((FormConnectionSettings)this.View).TXTUsername.Text);
            Data.Add("SQLPassword", ((FormConnectionSettings)this.View).TXTPassword.Text);
            Data.Add("SQLInitialCatalog", ((FormConnectionSettings)this.View).TXTInitialCatalog.Text);

            
           

            if (!this.IsTest)
            {
                Settings.CreateSettings("PQ_ConnectionSettings", "ConnectionSettings", ConnectionSettings, "1.0", Data);
                MessageBox.Show(this.View, "SQL Settings Created!", "Portable Query", MessageBoxButtons.OK, MessageBoxIcon.Information);
                this.View.Close();
            }
            return transaction;
        }

        public Transaction EndTransaction(Transaction transaction)
        {
            throw new NotImplementedException();
        }

        public Transaction Transact(Transaction transaction)
        {
            throw new NotImplementedException();
        }

        public Transaction ErrorTransaction(Transaction transaction)
        {
            MessageBox.Show(this.View, "Failed to connect to " + ((FormConnectionSettings)this.View).TXTHost.Text + Environment.NewLine +
                transaction.LastError.Message, this.GetType().Name, MessageBoxButtons.OK, MessageBoxIcon.Exclamation);

            LocalLogger.WriteLog(transaction.LastError.Message, LocalLogger.ApplicationLogs, true);
            LocalLogger.WriteLog(transaction.LastError.StackTrace, LocalLogger.ApplicationLogs, true);
            return transaction;
        }

        #endregion
    }
}
