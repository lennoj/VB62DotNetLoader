﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Portable_Query.Classes;
using Portable_Query.Classes.SQLTransact;
using Portable_Query.Forms;
using System.Windows.Forms;
using System.Data;
using System.Data.Sql;
using System.Data.SqlClient;
using System.Data.SqlTypes;
using System.IO;

namespace Portable_Query.Classes.Query
{
    public class SQLQuery : ITransaction
    {
        private Form View;
        private bool IsTest;
        private Action<DataTable,ProgressDialogBox> ExportCallback;

        public SQLQuery(Form View, bool isTest ,  Action<DataTable,ProgressDialogBox> ExportCallback)
        {
            this.View = View;
            this.IsTest = isTest;
            this.ExportCallback = ExportCallback;
        }

        #region ITransaction Members

        public Transaction BeginTransaction(Transaction transaction)
        {
            transaction.Command.CommandType = CommandType.Text;

            if (this.View.GetType() == typeof(FormQuerySettings))
                transaction.Command.CommandText = ((FormQuerySettings)this.View).TXTQuery.Text;
            else if (this.View.GetType() == typeof(FormMain))
            {
                string file = new FileInfo(Application.ExecutablePath).Directory.FullName + @"\QuerySettings.stg";
                if (File.Exists(file))
                {
                    string _conf_query = Settings.ReadEncryptedFile(file);
                    transaction.Command.CommandText = _conf_query;
                }
                else
                {
                    MessageBox.Show(this.View, "Please configure SQL Query first!", "Portable Query", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                    return transaction;
                }
            }


            SqlDataAdapter da = new SqlDataAdapter(transaction.Command);
            DataSet ds = new DataSet();

            ProgressDialogBox.ShowProgressDialogBox(this.View, "GetQueryResult", true, (ProgressDialogBox dialog) =>
            {
                dialog.UpdateDialog("Fetching data...", 30, false);
                dialog.StartMarqueeProgressBar();
                dialog.Wait(1000);
                da.Fill(ds);

                if (this.ExportCallback == null)
                {
                    if (ds.Tables.Count > 0)
                    {
                        CrossThread.Invoke(this.View, () =>
                        {
                            if (this.View.GetType() == typeof(FormQuerySettings))
                            {
                                ((FormQuerySettings)this.View).DGVQueryResult.DataSource = ds.Tables[0].DefaultView;
                                ((FormQuerySettings)this.View).LBLMessage.Text = "Total Row(s) Affected : " + ((FormQuerySettings)this.View).DGVQueryResult.Rows.Count;
                            }
                            else if (this.View.GetType() == typeof(FormMain))
                            {
                                ((FormMain)this.View).DGVQueryResult.DataSource = ds.Tables[0].DefaultView;
                                ((FormMain)this.View).LBLMessage.Text = "Total Row(s) Affected : " + ((FormMain)this.View).DGVQueryResult.Rows.Count;
                            }
                        });
                    }
                }
                else
                {
                    CrossThread.Invoke(this.View, () =>
                    {
                        if (this.View.GetType() == typeof(FormQuerySettings))
                            ((FormQuerySettings)this.View).LBLMessage.Text = "Total Row(s) Affected : " + ds.Tables[0].Rows.Count;
                        else if (this.View.GetType() == typeof(FormMain))
                            ((FormMain)this.View).LBLMessage.Text = "Total Row(s) Affected : " + ds.Tables[0].Rows.Count;
                    });

                   
                }


                dialog.StopMarqueeProgressBar();
                dialog.Wait(3000);

                if (this.ExportCallback != null)
                {
                    CrossThread.Invoke(this.View, () =>
                    {
                        this.ExportCallback(ds.Tables[0] , dialog);
                    });
                }
                

                dialog.UpdateDialog("Completed!", 100, true);
                dialog.Wait(1000);
            });

            return transaction;
        }

        public Transaction EndTransaction(Transaction transaction)
        {
            throw new NotImplementedException();
        }

        public Transaction Transact(Transaction transaction)
        {
            throw new NotImplementedException();
        }

        public Transaction ErrorTransaction(Transaction transaction)
        {
            if (this.View.GetType() == typeof(FormQuerySettings))
                ((FormQuerySettings)this.View).LBLMessage.Text = transaction.LastError.Message;
            else if (this.View.GetType() == typeof(FormMain))
                ((FormMain)this.View).LBLMessage.Text = transaction.LastError.Message;


            LocalLogger.WriteLog(transaction.LastError.Message, LocalLogger.ApplicationLogs, true);
            LocalLogger.WriteLog(transaction.LastError.StackTrace, LocalLogger.ApplicationLogs, true);
            return transaction;
        }

        #endregion
    }
}
