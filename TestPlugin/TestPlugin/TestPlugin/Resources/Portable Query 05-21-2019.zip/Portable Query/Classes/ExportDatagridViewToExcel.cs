﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using NPOI.SS.UserModel;
using NPOI.Util;
using NPOI.Util.Collections;
using NPOI.HSSF;
using NPOI.HSSF.UserModel;
using NPOI.HSSF.Util;
using NPOI.XSSF;
using NPOI.XSSF.UserModel;
using NPOI.XSSF.Util;
using NPOI.POIFS;
using NPOI.HPSF;
using NPOI.DDF;
using NPOI.OpenXml4Net.Util;
using NPOI.OpenXmlFormats.Spreadsheet;
using NPOI.WP.UserModel;
using System.Data;
using System.Windows.Forms;
using Portable_Query.Forms;
using System.Diagnostics;

namespace Portable_Query.Classes
{
    public class ExportDatagridViewToExcel
    {

        public static void Export(DataGridView DGV,string FilePath) 
        {
            bool error = false;

            if (DGV.Rows.Count == 0)
                MessageBox.Show(DGV.Parent, "No row(s) to be exported!", "Export To Excel", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
            else
            {
                Action<ProgressDialogBox> ProgressCallback = (ProgressDialogBox dialog) =>
                {

                    try
                    {
                        dialog.UpdateDialog("Creating Workbook " + FilePath, 0, false);
                        dialog.Wait(1000);
                        ExcelFactory ef = new ExcelFactory(FilePath);
                        ef.CreateNewWorkBook();
                        ef.AddSheet("Data");

                        dialog.UpdateDialog("Preparing Workbook...", 50, true);
                        dialog.Wait(1000);
                        ExcelFactory.CellTypeCallback<string> cb = (string value) =>
                        {
                            int intOut = 0;
                            decimal decOut = 0;
                            DateTime dateOut;

                            if (value.Length > 1 && value.StartsWith("0") && int.TryParse(value, out intOut)) // Check if padded numeric
                            {
                                return NPOI.SS.UserModel.CellType.String;
                            }
                            else if (DateTime.TryParse(value, out dateOut) || value.Contains("/"))  // Check if Date
                            {
                                return NPOI.SS.UserModel.CellType.Boolean;
                            }
                            else if (!int.TryParse(value, out intOut))  // Check if Alpha-Numeric
                            {
                                return NPOI.SS.UserModel.CellType.String;
                            }
                            else if (decimal.TryParse(value, out decOut))  // Check if decimal
                            {
                                return NPOI.SS.UserModel.CellType.Numeric;
                            }
                            else if (value.Length == 0) // Check if blank-empty
                            {
                                return NPOI.SS.UserModel.CellType.Blank;
                            }

                            return NPOI.SS.UserModel.CellType.String;
                        };

                        dialog.UpdateDialog("Exporting....", 100, true);
                        dialog.Wait(1000);

                        string[] values = null;
                        CrossThread.Invoke(DGV, () =>
                        {
                            values = new string[DGV.Columns.Count];
                        });

                        for (int i = 0; i < values.Length; i++)
                        {
                            CrossThread.Invoke(DGV, () =>
                            {
                                values[i] = DGV.Columns[i].Name.ToString();
                            });
                        }

                        ef.AddRowAt("Data", cb, "-" , "MM/dd/yyyy" , true , values);

                        double rowIndex = 0;
                        double maxRowIndex = 0;

                        CrossThread.Invoke(DGV, () =>
                        {
                            maxRowIndex = DGV.Rows.Count;
                        });

                        dialog.UpdateDialog("Exporting Row 0 of " + (int)maxRowIndex, 0, true);
                        dialog.Wait(500);



                        CrossThread.Invoke(DGV, () =>
                        {
                            foreach (DataGridViewRow row in DGV.Rows)
                            {
                                rowIndex += 1.0;
                                for (int i = 0; i < DGV.Columns.Count; i++)
                                {
                                    values[i] = row.Cells[i].Value.ToString();
                                }

                                ef.AddRowAt("Data",cb,  "-" , "MM/dd/yyyy",true, values);
                                dialog.UpdateDialog("Exporting Row " + rowIndex + " of " + DGV.Rows.Count, ((rowIndex / maxRowIndex) * 100), false);
                                if (((int)maxRowIndex) % 200 == 0) dialog.Wait(1);
                            }


                        });



                        dialog.Wait(3000);
                        dialog.UpdateDialog("Please wait...", 0, false);

                        try
                        {
                            ef.Close();
                            ef.Dispose();
                        }
                        catch (Exception __EX)
                        {
                            LocalLogger.WriteLog("Error On Export::WARNING FIRST CHANCE EXCEPTION", LocalLogger.ApplicationLogs, true);
                            LocalLogger.WriteLog("Source: " + __EX.Source, LocalLogger.ApplicationLogs, true);
                            LocalLogger.WriteLog(__EX.Message, LocalLogger.ApplicationLogs, true);
                            LocalLogger.WriteLog(__EX.StackTrace, LocalLogger.ApplicationLogs, true);
                        }

                        dialog.Wait(1000);
                        dialog.UpdateDialog("Export Complete!", 100, true);
                        dialog.Wait(1500);

                    }
                    catch (Exception Ex)
                    {
                        error = true;
                        LocalLogger.WriteLog("Error On Export", LocalLogger.ApplicationLogs, true);
                        LocalLogger.WriteLog("Source: " + Ex.Source, LocalLogger.ApplicationLogs, true);
                        LocalLogger.WriteLog(Ex.Message, LocalLogger.ApplicationLogs, true);
                        LocalLogger.WriteLog(Ex.StackTrace, LocalLogger.ApplicationLogs, true);
                    }


                };


                ProgressDialogBox.ShowProgressDialogBox((Form)DGV.Parent, "ExportToExcel", true, ProgressCallback);

                if (error)
                    MessageBox.Show((Form)DGV.Parent, "Error occured during export process" + Environment.NewLine + "Please contact your Software Vendor/Provider.", "Export To Excel", MessageBoxButtons.OK, MessageBoxIcon.Information);
                else
                {
                    MessageBox.Show((Form)DGV.Parent, "Export process completed!", "Export To Excel", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    try
                    {
                        Process procOpenExcel = Process.Start(FilePath);

                    }
                    catch (Exception OpenExcelFileEx)
                    {
                        LocalLogger.WriteLog("Error On Export", LocalLogger.ApplicationLogs, true);
                        LocalLogger.WriteLog("Source: " + OpenExcelFileEx.Source, LocalLogger.ApplicationLogs, true);
                        LocalLogger.WriteLog(OpenExcelFileEx.Message, LocalLogger.ApplicationLogs, true);
                        LocalLogger.WriteLog(OpenExcelFileEx.StackTrace, LocalLogger.ApplicationLogs, true);
                        MessageBox.Show((Form)DGV.Parent, "Error occured while trying to open file " + Environment.NewLine + FilePath + Environment.NewLine + "Please contact your Software Vendor/Provider.", "Export To Excel", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                }


            }
        }


        public static void Export(Form View , ProgressDialogBox dialog, DataTable Table, string FilePath)
        {
            bool error = false;

            if (Table.Rows.Count == 0)
                MessageBox.Show(View, "No row(s) to be exported!", "Export To Excel", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
            else
            {
                try
                {
                    dialog.UpdateDialog("Creating Workbook " + FilePath, 0, false);
                    dialog.Wait(1000);
                    ExcelFactory ef = new ExcelFactory(FilePath);
                    ef.CreateNewWorkBook();
                    ef.AddSheet("Data");

                    dialog.UpdateDialog("Preparing Workbook...", 50, true);
                    dialog.Wait(1000);
                    ExcelFactory.CellTypeCallback<string> cb = (string value) =>
                    {
                        int intOut = 0;
                        decimal decOut = 0;
                        DateTime dateOut;

                        if (value.Length > 1 && value.StartsWith("0") && int.TryParse(value, out intOut)) // Check if padded numeric
                        {
                            return NPOI.SS.UserModel.CellType.String;
                        }
                        else if (DateTime.TryParse(value, out dateOut) || value.Contains("/"))  // Check if Date
                        {
                            return NPOI.SS.UserModel.CellType.Boolean;
                        }
                        else if (!int.TryParse(value, out intOut))  // Check if Alpha-Numeric
                        {
                            return NPOI.SS.UserModel.CellType.String;
                        }
                        else if (decimal.TryParse(value, out decOut))  // Check if decimal
                        {
                            return NPOI.SS.UserModel.CellType.Numeric;
                        }
                        else if (value.Length == 0) // Check if blank-empty
                        {
                            return NPOI.SS.UserModel.CellType.Blank;
                        }

                        return NPOI.SS.UserModel.CellType.String;
                    };

                    dialog.UpdateDialog("Exporting....", 100, true);
                    dialog.Wait(1000);

                    string[] values = new string[Table.Columns.Count];

                    for (int i = 0; i < values.Length; i++)
                    {
                        values[i] = Table.Columns[i].ColumnName.ToString();
                    }

                    ef.AddRowAt("Data", cb, "-" , "MM/dd/yyyy",true, values);

                    double rowIndex = 0;
                    double maxRowIndex = Table.Rows.Count; ;

                    dialog.UpdateDialog("Exporting Row 0 of " + (int)maxRowIndex, 0, true);
                    dialog.Wait(500);


                    foreach (DataRow row in Table.Rows)
                    {
                        rowIndex += 1.0;
                        for (int i = 0; i < values.Length; i++)
                        {
                            values[i] = row[i].ToString();
                        }

                        ef.AddRowAt("Data", cb,  "-" , "MM/dd/yyyy", true, values);
                        dialog.UpdateDialog("Exporting Row " + rowIndex + " of " + Table.Rows.Count, ((rowIndex / maxRowIndex) * 100), false);
                        if (((int)maxRowIndex) % 200 == 0) dialog.Wait(1);
                    }


                    dialog.Wait(3000);
                    dialog.UpdateDialog("Please wait...", 0, false);

                    try
                    {
                        ef.Close();
                        ef.Dispose();
                    }
                    catch (Exception __EX)
                    {
                        LocalLogger.WriteLog("Error On Export::WARNING FIRST CHANCE EXCEPTION", LocalLogger.ApplicationLogs, true);
                        LocalLogger.WriteLog("Source: " + __EX.Source, LocalLogger.ApplicationLogs, true);
                        LocalLogger.WriteLog(__EX.Message, LocalLogger.ApplicationLogs, true);
                        LocalLogger.WriteLog(__EX.StackTrace, LocalLogger.ApplicationLogs, true);
                    }

                    dialog.Wait(1000);
                    dialog.UpdateDialog("Export Complete!", 100, true);
                    dialog.Wait(1500);

                }
                catch (Exception Ex)
                {
                    error = true;
                    LocalLogger.WriteLog("Error On Export", LocalLogger.ApplicationLogs, true);
                    LocalLogger.WriteLog("Source: " + Ex.Source, LocalLogger.ApplicationLogs, true);
                    LocalLogger.WriteLog(Ex.Message, LocalLogger.ApplicationLogs, true);
                    LocalLogger.WriteLog(Ex.StackTrace, LocalLogger.ApplicationLogs, true);
                }

                //ProgressDialogBox.ShowProgressDialogBox(View, "ExportToExcel", true, ProgressCallback );

                if (error)
                    MessageBox.Show(dialog, "Error occured during export process" + Environment.NewLine + "Please contact your Software Vendor/Provider.", "Export To Excel", MessageBoxButtons.OK, MessageBoxIcon.Information);
                else
                {
                    MessageBox.Show(dialog, "Export process completed!", "Export To Excel", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    try
                    {
                        Process procOpenExcel = Process.Start(FilePath);
                        
                    }
                    catch (Exception OpenExcelFileEx)
                    {
                        LocalLogger.WriteLog("Error On Export", LocalLogger.ApplicationLogs, true);
                        LocalLogger.WriteLog("Source: " + OpenExcelFileEx.Source, LocalLogger.ApplicationLogs, true);
                        LocalLogger.WriteLog(OpenExcelFileEx.Message, LocalLogger.ApplicationLogs, true);
                        LocalLogger.WriteLog(OpenExcelFileEx.StackTrace, LocalLogger.ApplicationLogs, true);
                        MessageBox.Show(dialog, "Error occured while trying to open file " + Environment.NewLine +FilePath + Environment.NewLine + "Please contact your Software Vendor/Provider.", "Export To Excel", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }

                }


            }
        }
    }
}
