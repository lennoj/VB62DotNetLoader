﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;
using NPOI.HSSF.UserModel;
using NPOI.SS.UserModel;


// Added by Jonnel 10-11-2018
namespace Portable_Query.Classes
{
    /// <summary>
    /// ExcelFactory : Use for Generation of excel workbook (PLEASE DO NOT EDIT THIS CLASS IF YOU DON'T WANT TO MESS WITH THE OTHER CLASS!)
    /// UPDATE AT YOUR OWN RISK
    /// JPMendoza 05-02-2019
    /// </summary>
    public class ExcelFactory : IDisposable
    {
        private string Filename;
        private HSSFWorkbook Workbook;
        private FileStream fstream;
        public delegate CellType CellTypeCallback<T>(T param);


        public ExcelFactory(string filename)
        {
            this.Filename = filename;
        }


        public FileInfo CreateNewWorkBook()
        {
            this.fstream = null;

            try
            {
                // Initial creation of workbook file in the drive path
                this.fstream = new FileStream(this.Filename, FileMode.Create, FileAccess.Write, FileShare.ReadWrite);
                this.Workbook = new HSSFWorkbook();

                if (this.Workbook != null)
                {
                    return new FileInfo(this.Filename);
                }

                return null;
            }
            catch (Exception ex)
            {
                LocalLogger.WriteLog(ex.Message + "\n" + ex.StackTrace, LocalLogger.ErrorLogs, true);
                //Console.WriteLine(ex.Message);
                //Console.WriteLine(ex.StackTrace);
                return null;
            }
            finally
            {
                if (this.Workbook != null) this.Workbook.Close();
            }
        }

        public HSSFSheet AddSheet(string sheetName)
        {
            if (this.Workbook != null)
            {
                return (HSSFSheet)this.Workbook.CreateSheet(sheetName);
            }
            else
                throw new NullReferenceException();

        }

        protected HSSFRow AddRow(string sheetName)
        {
            int index = this.Workbook.GetSheetIndex(sheetName);
            if (index <= -1) throw new Exception("Sheet " + sheetName + " doesn't exist!\n AddRow(string sheetName)");

            HSSFSheet sheet = (HSSFSheet)this.Workbook.GetSheetAt(index);
            int currentRowIndex = (sheet.Sheet.GetRow(0) == null ? 0 : sheet.LastRowNum + 1);
            HSSFRow row = (HSSFRow)sheet.CreateRow(currentRowIndex);

            return row;
        }

        protected HSSFCell AddCell(HSSFRow row, object value, CellType dType)
        {
            if (row != null)
                return (HSSFCell)row.CreateCell(row.Cells.Count, dType);

            return null;
        }

        public void AddRowAt(string sheetName, CellTypeCallback<string> valueToCelltypeTest, string separator, string format, bool autoRound, params string[] values)
        {
            HSSFRow row = this.AddRow(sheetName);


            foreach (string element in values)
            {
                HSSFCell cell = (HSSFCell)row.CreateCell(row.Cells.Count, valueToCelltypeTest(element));

                Action MainEvent = () =>
                {
                    switch (cell.CellType)
                    {
                        case CellType.Numeric: 
                            {
                                if(autoRound)
                                    cell.SetCellValue(Math.Round(Double.Parse(element), 2)); 
                                else
                                    cell.SetCellValue(Double.Parse(element)); 
                                break;
                            }
                        case CellType.String: cell.SetCellValue(element); break;
                        case CellType.Boolean:
                            {
                                // For date type
                                if (element.Length > 10)
                                {
                                    cell.SetCellType(CellType.String);
                                    cell.SetCellValue(element);
                                    return;
                                }
                                cell.SetCellType(CellType.String);
                                string retVal = ForceDateTimeParse(element, separator , format);
                                cell.SetCellValue(retVal);
                                break;
                            }
                    }

                };


                Action<Exception> OnError = (Exception ex) =>
                {
                    // DO NOT DELETE THIS (For DEBUGGING PURPOSES) - JPMENDOZA 05-02-2019
                    //LocalLogger.WriteLog("An Error occured in trying to convert data", LocalLogger.ErrorLogs, true);
                    //LocalLogger.WriteLog("Row: " + row.RowNum, LocalLogger.ErrorLogs, true);
                    //LocalLogger.WriteLog("Column: " + cell.ColumnIndex, LocalLogger.ErrorLogs, true);
                    //LocalLogger.WriteLog("Data/Value failed to convert: '" + element + "'", LocalLogger.ErrorLogs, true);
                    //LocalLogger.WriteLog("Error reason:" + ex.Message, LocalLogger.ErrorLogs, true);
                    // DO NOT DELETE THIS (For DEBUGGING PURPOSES) - JPMENDOZA 05-02-2019
                };


                MainEvent();
            }
        }



        public static string ForceDateTimeParse(string param , string separator , string format)
        {
            DateTime dateOut;

            if (param.Contains("-") && param.Contains(":"))
                return param;

            param = (param.Contains("/") ? param.Replace("/", "-") : param);
            param = (param.Contains(":") ? param.Replace(":", "") : param);


            try
            {
                if (param.Split('-').Length > 2)
                    param = param.Remove(10, param.Length - 10);
                else
                    return param;
            }
            catch (Exception Ex)
            {
                LocalLogger.WriteLog(Ex.Message + ":" + param , LocalLogger.ApplicationLogs , true);
                return param;
            }

            string[] tokens = param.Split('-');

            if (tokens.Length < 3) return param;

            if (DateTime.TryParse(param, out dateOut))
            {
                return dateOut.ToString(format);
            }
            else
            {
                // try mm-dd-yyyy
                int day = 0;
                int month = 0;
                int year = 0;

                if (tokens[0].Length == 4)
                {
                    year = int.Parse(tokens[0]);
                    month = int.Parse(tokens[2]);
                    day = int.Parse(tokens[1]);
                }
                else if (tokens[1].Length == 4)
                {
                    year = int.Parse(tokens[1]);
                    month = int.Parse(tokens[0]);
                    day = int.Parse(tokens[2]);
                }
                else if (tokens[2].Length == 4)
                {
                    year = int.Parse(tokens[2]);
                    month = int.Parse(tokens[0]);
                    day = int.Parse(tokens[1]);
                }
                else
                {
                    year = int.Parse(tokens[2]);
                    month = int.Parse(tokens[0]);
                    day = int.Parse(tokens[1]);
                }

                // swap to day if month > 12
                if (month > 12)
                {
                    month = month + day;
                    day = month - day;
                    month = month - day;
                }

                // Check if mm-dd-yyyy
                if (DateTime.TryParse(month + "-" + day + "-" + year, out dateOut)) return dateOut.ToString(format);

                // Check if dd-mm-yyyy
                if (DateTime.TryParse(day + "-" + month + "-" + year, out dateOut)) return dateOut.ToString(format);

                // Check if yyyy-mm-dd
                if (DateTime.TryParse(year + "-" + month + "-" + day, out dateOut)) return dateOut.ToString(format);

                // Check if yyyy-dd-mm
                if (DateTime.TryParse(year + "-" + day + "-" + month, out dateOut)) return dateOut.ToString(format);

                return day + separator + month + separator + year;
            }
        }

        public void AutoFit(string sheetName, int maxColumnIndex)
        {
            HSSFSheet sheet = (HSSFSheet)this.Workbook.GetSheet(sheetName);

            for (int x = 0; x < maxColumnIndex; x++)
            {
                sheet.AutoSizeColumn(x);
            }
        }

        public void Close()
        {
            if (this.Workbook != null)
            {
                this.Workbook.SummaryInformation = NPOI.HPSF.PropertySetFactory.CreateSummaryInformation();
                this.Workbook.SummaryInformation.Author = "Portable Query";
                this.Workbook.SummaryInformation.Comments = "Portable Query version 05-16-2018\nBy Jonnel ross Mendoza";
                this.Workbook.SummaryInformation.LastAuthor = "Jonnel ross Mendoza";
                this.Workbook.SummaryInformation.Title = "Portable Query";
                this.Workbook.SummaryInformation.Subject = "Portable Query";
                this.Workbook.Write(this.fstream);
                this.Workbook.Close();
                if (this.fstream != null) this.fstream.Close();
            }
        }

        #region IDisposable Members

        public void Dispose()
        {
            if (this.Workbook != null)
            {
                this.Workbook.Close();
                if (this.fstream != null) this.fstream.Close();
            }

            this.Workbook = null;
        }

        #endregion
    }
}
