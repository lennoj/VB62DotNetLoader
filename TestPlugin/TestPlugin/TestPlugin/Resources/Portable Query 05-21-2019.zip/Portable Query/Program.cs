﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows.Forms;
using Portable_Query.Forms;
using System.Reflection;
using BugTrap;
using Portable_Query.Classes;
using Animator;

namespace Portable_Query
{
    //  UserSettings.stg            Contains User Settings (Username and Password)
    //  QuerySettings.stg           Contains Query Settings (SELECT STATEMENT)
    //  ConnectionSettings.stg      Contains Connection Settings (SQL Username and Password)
    static class Program
    {
        /// <summary>
        /// The main entry point for the application.
        /// </summary>
        [STAThread]
        static void Main()
        {
            BugTrap.BugTrapHandler.Initialize("itechline@natcco.coop", "http://osticket.natcco.coop:8084", "Portable Query",
                Assembly.GetExecutingAssembly().GetName().Version.ToString(), null, null,
                Properties.Resources.FTPServer,
                Properties.Resources.FTPUsername,
                Properties.Resources.FTPPassword,
                Properties.Resources.FTPFolder, true);

            LocalLogger.ApplicationLogs = new System.IO.FileInfo(Application.ExecutablePath).Directory.FullName + @"\PortableQueryStates.stg";
            LocalLogger.WriteLog("Applcation Started : " + DateTime.Now.ToLocalTime().ToString("MM-dd-yyyy dddd, hh:mm:ss tt ") , LocalLogger.ApplicationLogs, false);
            LocalLogger.WriteLog("========================================================================================================", LocalLogger.ApplicationLogs, true);

            
            //int x = int.Parse("0099999999999999999");
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            AnimationEngine.StartUIEngine();
            AnimationEngine.SetFPS(60);
            AnimationEngine.SetAnimationSmoothness(AnimationSmoothness.Smooth);
            Application.Run(new FormMain());

            LocalLogger.WriteLog("Applcation End : " + DateTime.Now.ToLocalTime().ToString("MM-dd-yyyy dddd, hh:mm:ss tt "), LocalLogger.ApplicationLogs, true);
            LocalLogger.WriteLog("========================================================================================================", LocalLogger.ApplicationLogs, true);
        }
    }
}
