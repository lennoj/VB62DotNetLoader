﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Threading;
using Animator;
using Portable_Query.Classes;


namespace Portable_Query.Forms
{
    public partial class ProgressDialogBox : Form
    {
        private Form _PARENT;
        private DateTime _StartTime;
        public DateTime StartTime { get { return this._StartTime; } }
        private string _TaskName;
        private Action<ProgressDialogBox> _MainEvent;
        private Thread _EventThread;
        private Thread _ElapseTimeThread;
        private bool _AllowPause;
        private TimeSpan ElapseTime;
        private Effect effect;
        private bool _IsMarqueeProgressBar;
        private int _MAX_PROGRESS_WITH = 682;
        private int _ORIGINAL_LEFT = 12;

        public TimeSpan TotalElapseTime { get { return this.ElapseTime;  } }
        public string Status { get { return this.LBLStatus.Text; } set { this.LBLStatus.Text = value; } }
        public int Value { get { return (int)((this.LBLProgress.Width / 682) * 100); } 
            set 
            {
                value = (value < 0 ? 0 :
                                         (value > 100 ? 100 : value));

                this.LBLProgress.Width = (int)((double)value / 100.0) * 682;
            }
        }


        #pragma warning disable
        public ProgressDialogBox(Form Parent, String TaskName , bool AllowPause , Action<ProgressDialogBox> MainEvent)
        {
            InitializeComponent();
            this.LBLProgress.Text = "";
            this.LBLStatus.Text = "0%";
            this.MainProgressBar.Width = 0;
            this._PARENT = Parent;
            this._MainEvent = MainEvent;
            this._TaskName = TaskName;
            this.LBLElapseTime.Text = "Total Elapse Time : 00:00:00";

            this._ElapseTimeThread = new Thread(() =>
            {
                while (!this.IsDisposed)
                {
                    CrossThread.Invoke(this.LBLElapseTime, () =>
                    {
                        ElapseTime = DateTime.Now.ToLocalTime() - this.StartTime;
                        this.LBLElapseTime.Text = "Total Elapse Time : " + (ElapseTime.Hours < 10 ? "0" + ElapseTime.Hours : "" + ElapseTime.Hours) + ":" +
                            (ElapseTime.Minutes < 10 ? "0" + ElapseTime.Minutes : "" + ElapseTime.Minutes) + ":" + (ElapseTime.Seconds < 10 ? "0" + ElapseTime.Seconds : "" + ElapseTime.Seconds);
                        this.LBLElapseTime.Update();
                        this.LBLElapseTime.Refresh();

                        if (ElapseTime.Seconds == 0) // Garbage Collect Every 60 seconds
                        {
                            for (int i = 0; i < 10; i++)
                            {
                                System.GC.Collect(i, GCCollectionMode.Forced);
                            }
                        }
                    });



                    this.Wait(256);
                }
            });

            this._ElapseTimeThread.IsBackground = true;
            this._ElapseTimeThread.SetApartmentState(ApartmentState.STA);
            this._ElapseTimeThread.Priority = ThreadPriority.BelowNormal;
            this._ElapseTimeThread.Name = "ElapseTime Thread";

            this._EventThread = new Thread(() =>
            {
                if (this._MainEvent != null)
                    this._MainEvent(this);

                try
                {
                    while (this._ElapseTimeThread.IsAlive)
                    {
                        this._ElapseTimeThread.Suspend();
                        this._ElapseTimeThread.Abort();
                        Thread.Sleep(1);
                    }
                }
                catch (Exception Ex)
                {
                    Console.WriteLine(Ex.Message);
                    Console.WriteLine(Ex.StackTrace);
                }

                CrossThread.Invoke(this, () =>
                {
                    this.Wait(1000);
                    this.Close();
                });
            });
           
            this._EventThread.IsBackground = true;
            this._EventThread.SetApartmentState(ApartmentState.STA);
            this._EventThread.Priority = ThreadPriority.Normal;
            this._EventThread.Name = TaskName;
            this._AllowPause = AllowPause;

            BTNEventState.Visible = AllowPause;
            if (AllowPause)
                this.Size = new Size(705, 160);
            else
                this.Size = new Size(705, 115);
            this.Text = TaskName;
        }

        public void Wait(int delay) 
        {
            Thread.Sleep(delay);
            CrossThread.Invoke(this, () =>
            {
                this.Update();
                this.Refresh();
                Application.DoEvents();
            });
        }

        public void UpdateProgress(double value, bool isAnimated) 
        {
            int newValue = (int)Math.Round(value, 2);
            double newWidth = 0;
            CrossThread.Invoke(this.MainProgressBar, () =>
            {
                newValue = (newValue < 0 ? 0 :
                                         (newValue > 100 ? 100 : newValue));

                newWidth = ((double)newValue / 100.0) * 682;
                if (!isAnimated)
                {
                    this.MainProgressBar.Width = (int)newWidth;
                    this.MainProgressBar.Update();
                    this.MainProgressBar.Refresh();
                }
            });

            if (isAnimated && !_IsMarqueeProgressBar)
            {
                if (this.effect == null)
                    this.effect = AnimationEngine.AnimateEasing(this.MainProgressBar, "Width", (int)newWidth, EasingStyle.EaseInOutCubic, 0.5f, false, 1);
                else
                {
                    this.effect.SkipAnimation();
                    this.effect.Stop();
                    if (this.effect.isEnded())
                        if (AnimationEngine.QueueCount < 2)
                            this.effect = AnimationEngine.AnimateEasing(this.MainProgressBar, "Width", (int)newWidth, EasingStyle.EaseInOutCubic, 0.5f, false, 1);
                }
            }
        }


        public void StartMarqueeProgressBar() 
        {
            _IsMarqueeProgressBar = true;
            if (this.effect != null)
                this.effect.SkipAnimation();

            //this.MainProgressBar.Width = (int)_MAX_PROGRESS_WITH * (int)0.4;
            this.effect = AnimationEngine.AnimateEasing(this.MainProgressBar, "Left", _MAX_PROGRESS_WITH - (int)this.MainProgressBar.Width, EasingStyle.EaseInOutCubic, 1f, true, -1);
            this.effect.OnReflect += (Effect effectArgs)=>
            {
                 if (!_IsMarqueeProgressBar)
                 {
                    effectArgs.Stop();
                    this.effect = this.effect = AnimationEngine.AnimateEasing(this.MainProgressBar, "Left", _ORIGINAL_LEFT, EasingStyle.EaseInOutCubic, 1f, false, 1); 
                    this.effect.OnEnd += (Effect effect) =>
                    {
                        AnimationEngine.AnimateEasing(this.MainProgressBar, "Width", 45, EasingStyle.EaseInOutCubic, 1f, false, 1);
                    };
                }
            };
        }

        public void StopMarqueeProgressBar()
        {
            _IsMarqueeProgressBar = false;
        }




        public void UpdateDialog(string status, double value , bool isAnimated) 
        {
            int newValue = (int)Math.Round(value,2);
            double newWidth = 0;
            CrossThread.Invoke(this.MainProgressBar, () =>
            {
                newValue = (newValue < 0 ? 0 :
                                         (newValue > 100 ? 100 : newValue));

                newWidth = ((double)newValue / 100.0) * 682;
                if (!isAnimated)
                {
                    this.MainProgressBar.Width = (int)newWidth;
                    this.MainProgressBar.Update();
                    this.MainProgressBar.Refresh();
                }
            });

            if (isAnimated && !_IsMarqueeProgressBar)
            {
                if (this.effect == null)
                    this.effect = AnimationEngine.AnimateEasing(this.MainProgressBar, "Width", (int)newWidth, EasingStyle.EaseInOutCubic, 0.5f, false, 1);
                else
                {
                    this.effect.SkipAnimation();
                    this.effect.Stop();
                    if (this.effect.isEnded())
                        if (AnimationEngine.QueueCount < 2)
                            this.effect = AnimationEngine.AnimateEasing(this.MainProgressBar, "Width", (int)newWidth, EasingStyle.EaseInOutCubic, 0.5f, false, 1);
                }
            }
            

            CrossThread.Invoke(this.LBLStatus, () =>
            {
                this.LBLStatus.Text = status;
                this.LBLProgress.Text = newValue + "%";
                this.LBLProgress.Update();
                this.LBLProgress.Refresh();
            });

            Application.DoEvents();
        }

        public static void ShowProgressDialogBox(Form Parent, String TaskName, bool AllowPause, Action<ProgressDialogBox> MainEvent) 
        {
            LocalLogger.WriteLog(DateTime.Now.ToLocalTime().ToString("MM-dd-yyyy_hh:mm:ss tt ")  + typeof(ProgressDialogBox).Name + "::CREATE_PROGRESSBOX_DIALOGBOX_INSTANCE", LocalLogger.ApplicationLogs, true);
            ProgressDialogBox PDB = new ProgressDialogBox(Parent, TaskName, AllowPause, MainEvent);
            PDB.ShowDialog(Parent);
            LocalLogger.WriteLog(DateTime.Now.ToLocalTime().ToString("MM-dd-yyyy_hh:mm:ss tt ")  + typeof(ProgressDialogBox).Name + "::DESTROY_PROGRESSBOX_DIALOGBOX_INSTANCE", LocalLogger.ApplicationLogs, true);
        }

       
        public void ShowDialog(IWin32Window parent) 
        {
            this.Start();
            base.ShowDialog(parent);
            if (this.effect != null) 
            {
                try
                {
                    this.effect.Dispose();
                }
                catch (Exception ex)
                {
                    Console.WriteLine(ex.Message);
                    Console.WriteLine(ex.StackTrace);
                }
                finally
                {
                    this.effect = null;
                }
            }
            
            AnimationEngine.StopAllAnimations();
            
        }


        public void Start() 
        {
            if (this._EventThread != null)
                if (!this._EventThread.IsAlive)
                {
                    Thread.Sleep(2000);
                    this._StartTime = DateTime.Now.ToLocalTime();
                    this._ElapseTimeThread.Start();
                    this._EventThread.Start();
                }
        }

        public void Pause() 
        {
            if (this._EventThread != null)
                if (this._EventThread.IsAlive)
                {
                    this._ElapseTimeThread.Suspend();
                    this._EventThread.Suspend();
                    CrossThread.Invoke(this.LBLStatus, () => this.UpdateDialog("Pause in process :: " + this.LBLStatus.Text, 100 , true));
                }
        }

        public void Resume()
        {
            if (this._EventThread != null)
                if (this._EventThread.IsAlive && (this._EventThread.ThreadState == (ThreadState.Background | ThreadState.Suspended)))
                {
                    CrossThread.Invoke(this.LBLStatus, () => this.UpdateDialog("Resuming proces... Please wait..", 100 , true));
                    this.Wait(2000);
                    this._ElapseTimeThread.Resume();
                    this._EventThread.Resume();
                }
        }

        public void Abort()
        {
            if (this._EventThread != null)
                if (this._EventThread.IsAlive && (this._EventThread.ThreadState == ThreadState.Suspended || this._EventThread.ThreadState == ThreadState.Running || this._EventThread.ThreadState == ThreadState.Background))
                {
                    try
                    {
                        while (this._EventThread.IsAlive)
	                    {
	                        this._EventThread.Suspend();
                            this._EventThread.Abort();
                            this._ElapseTimeThread.Suspend();
                            this._ElapseTimeThread.Abort();
                            Thread.Sleep(1);
	                    }
                    }
                    catch (Exception Ex)
                    {
                        Console.WriteLine(Ex.Message);
                        Console.WriteLine(Ex.StackTrace);
                    }

                    CrossThread.Invoke(this, () =>
                    {
                        this.Close();
                    });
                }
        }

        #pragma warning restore

        private void BTNEventState_Click(object sender, EventArgs e)
        {
            if (BTNEventState.Text.Equals("Pause"))
            {
                this.Pause();
                BTNEventState.Text = "Resume";
            }
            else if (BTNEventState.Text.Equals("Resume"))
            {
                this.Resume();
                BTNEventState.Text = "Pause";
            }
        }

        private void ProgressDialogBox_FormClosing(object sender, FormClosingEventArgs e)
        {
            System.GC.Collect(1, GCCollectionMode.Optimized);
            System.GC.Collect(2, GCCollectionMode.Optimized);
            System.GC.Collect(3, GCCollectionMode.Optimized);
            System.GC.Collect(4, GCCollectionMode.Optimized);
            System.GC.Collect(5, GCCollectionMode.Optimized);

        }





    }
}
