﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using Portable_Query.Classes;
using Portable_Query.Classes.SQLTransact;
using Portable_Query.Classes.Query;
using System.IO;

namespace Portable_Query.Forms
{
    public partial class FormQuerySettings : Form
    {
        
        public FormQuerySettings()
        {
            InitializeComponent();
            this.DGVQueryResult.ForeColor = Color.Black;
            this.DGVQueryResult.MultiSelect = true;
            this.DGVQueryResult.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            this.DGVQueryResult.RowHeadersVisible = false;
            this.DGVQueryResult.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.AllCells;
            this.DGVQueryResult.AllowUserToResizeColumns = false;
            this.DGVQueryResult.AllowUserToResizeRows = false;
            string conftFile = new FileInfo(Application.ExecutablePath).Directory.FullName + @"\QuerySettings.stg";
            if (File.Exists(conftFile))
            {
                TXTQuery.Text = Settings.ReadEncryptedFile(conftFile);
            }
        }

        private bool IsConnectionSetup()
        {
            string ConnectionSettings = new FileInfo(Application.ExecutablePath).Directory.FullName + @"\ConnectionSettings.stg";

            return File.Exists(ConnectionSettings);
        }

        private void BTNTest_Click(object sender, EventArgs e)
        {
            if (IsConnectionSetup())
            {
                Settings conSettings = Settings.LoadSettings(new FileInfo(Application.ExecutablePath).Directory.FullName + @"\ConnectionSettings.stg", "1.0");
                SQLTransaction.CreateTransaction(conSettings["SQLHost"], conSettings["SQLUsername"], conSettings["SQLPassword"], conSettings["SQLInitialCatalog"], new SQLQuery(this, true , null)).Begin();
            }
            else
                MessageBox.Show(this, "Please configure SQL Connection settings first!", "Query Settings", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
        }

        private void BTNSave_Click(object sender, EventArgs e)
        {
            Settings.WriteEncryptedFile(new FileInfo(Application.ExecutablePath).Directory.FullName + @"\QuerySettings.stg", TXTQuery.Text);
            MessageBox.Show(this, "Query Saved!", "Query Settings", MessageBoxButtons.OK, MessageBoxIcon.Information);
            Close();
        }

    }
}
