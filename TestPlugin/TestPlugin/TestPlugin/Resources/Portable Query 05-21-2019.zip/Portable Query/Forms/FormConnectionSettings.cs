﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using Portable_Query.Classes;
using Portable_Query.Classes.SQLTransact;
using Portable_Query.Classes.Query;
using System.IO;

namespace Portable_Query.Forms
{
    public partial class FormConnectionSettings : Form
    {
        private Settings conSettings;
        
        public FormConnectionSettings()
        {
            InitializeComponent();

            if (IsConnectionSetup())
                conSettings = Settings.LoadSettings(new FileInfo(Application.ExecutablePath).Directory.FullName + @"\ConnectionSettings.stg", "1.0");

            if (conSettings != null)
            {
                TXTHost.Text = conSettings["SQLHost"];
                TXTUsername.Text = conSettings["SQLUsername"];
                TXTPassword.Text = conSettings["SQLPassword"];
                TXTInitialCatalog.Text = conSettings["SQLInitialCatalog"];

            }
        }


        private bool IsConnectionSetup()
        {
            string ConnectionSettings = new FileInfo(Application.ExecutablePath).Directory.FullName + @"\ConnectionSettings.stg";

            return File.Exists(ConnectionSettings);
        }

        private void BTNSave_Click(object sender, EventArgs e)
        {
            if (ValidateCredentials())
                SQLTransaction.CreateTransaction(TXTHost.Text, TXTUsername.Text, TXTPassword.Text, TXTInitialCatalog.Text ,  new SQLConnectionTest(this, conSettings, false)).Begin();

        }

        private void BTNTest_Click(object sender, EventArgs e)
        {
            if (ValidateCredentials())
                SQLTransaction.CreateTransaction(TXTHost.Text, TXTUsername.Text, TXTPassword.Text , TXTInitialCatalog.Text, new SQLConnectionTest(this, conSettings, true)).Begin();
        }


        private bool ValidateCredentials()
        {
            if (TXTHost.Text.Trim().Length == 0)
            {
                MessageBox.Show(this, "Host required!", "Portable Query", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                return false;
            }

            if (TXTUsername.Text.Trim().Length == 0)
            {
                MessageBox.Show(this, "Username required!", "Portable Query", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                return false;
            }

            return true;

            
        }





    }
}
