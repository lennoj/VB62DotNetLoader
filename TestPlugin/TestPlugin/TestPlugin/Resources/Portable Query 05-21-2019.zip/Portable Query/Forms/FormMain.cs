﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.IO;
using System.Windows.Forms;
using Portable_Query.Classes;
using Portable_Query.Classes.Query;
using Portable_Query.Classes.SQLTransact;

namespace Portable_Query.Forms
{
    public partial class FormMain : Form
    {
        public FormMain()
        {
            InitializeComponent();
            this.DGVQueryResult.MultiSelect = true;
            this.DGVQueryResult.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            this.DGVQueryResult.RowHeadersVisible = false;
            this.DGVQueryResult.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.AllCells;
            this.DGVQueryResult.ForeColor = Color.Black;
            this.DGVQueryResult.AllowUserToResizeColumns = false;
            this.DGVQueryResult.AllowUserToResizeRows = false;
        }

        private void exitToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void DGVQueryResult_KeyUp(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.F5)
                Console.WriteLine("Refresh");
             
        }

        private void connectionSettginsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FormAdministratorSettings frm = new FormAdministratorSettings(FormAdministratorSettings.FormType.Authenticate);
            if (!IsAdminSetup())
                new FormConnectionSettings().ShowDialog(this);
            else
            {
                DialogResult result = frm.ShowDialog(this);
                if (result == DialogResult.OK)
                    new FormConnectionSettings().ShowDialog(this);
            }   
        }

        private void adminSettingsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            // Check of Config Exist. UserSettings.stg
            FormAdministratorSettings frm = null;

            if (!IsAdminSetup())
            {
                frm = new FormAdministratorSettings(FormAdministratorSettings.FormType.SaveSettings);
                frm.ShowDialog(this);
            }
            else
            {
                frm = new FormAdministratorSettings(FormAdministratorSettings.FormType.Authenticate);
                DialogResult result = frm.ShowDialog(this);
                if(result == DialogResult.OK)
                    new FormAdministratorSettings(FormAdministratorSettings.FormType.SaveSettings).ShowDialog(this);
            }
            
            
                
        }

        private bool IsAdminSetup() 
        {
            string UserSettings = new FileInfo(Application.ExecutablePath).Directory.FullName + @"\UserSettings.stg";

            return File.Exists(UserSettings);
        }


        private Settings GetUserSettings() 
        {
            string UserSettings = new FileInfo(Application.ExecutablePath).Directory.FullName + @"\UserSettings.stg";
            return Settings.LoadSettings(UserSettings, "1.0");
        }

        private void querySettingsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FormAdministratorSettings frm = new FormAdministratorSettings(FormAdministratorSettings.FormType.Authenticate);
            if (!IsAdminSetup())
                new FormQuerySettings().ShowDialog(this);
            else
            {
                DialogResult result = frm.ShowDialog(this);
                if (result == DialogResult.OK)
                    new FormQuerySettings().ShowDialog(this);
            }
        }

        private void refreshToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (IsConnectionSetup())
            {
                Settings conSettings = Settings.LoadSettings(new FileInfo(Application.ExecutablePath).Directory.FullName + @"\ConnectionSettings.stg", "1.0");
                SQLTransaction.CreateTransaction(conSettings["SQLHost"], conSettings["SQLUsername"], conSettings["SQLPassword"], conSettings["SQLInitialCatalog"], new SQLQuery(this, true , null)).Begin();
            }
            else
                MessageBox.Show(this, "Please configure SQL Connection settings first!", "Query Settings", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
        }


        private bool IsConnectionSetup()
        {
            string ConnectionSettings = new FileInfo(Application.ExecutablePath).Directory.FullName + @"\ConnectionSettings.stg";

            return File.Exists(ConnectionSettings);
        }

        private void exportToExcelToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Export(null,null);   
        }


        private void Export(DataTable dt,ProgressDialogBox dialog) 
        {
            if (DGVQueryResult.Rows.Count == 0 && dt == null)
            {
                MessageBox.Show(this, "No row(s) to be exported!", "Export To Excel", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                return;
            }

            SaveFileDialog sfd = new SaveFileDialog();
            DialogResult result = DialogResult.No;
            if (dialog != null)
            {
                dialog.Visible = false;
                sfd.Title = "Export To Excel(Save)";
                sfd.Filter = "Excel 2003(*.xls)|*.xls|Excel 2007(*.xlsx)|*.xlsx|All(*.*)|*.*";
                result = sfd.ShowDialog(this);
                dialog.Visible = true;
            }
            else
            {
                sfd.Title = "Export To Excel(Save)";
                sfd.Filter = "Excel 2003(*.xls)|*.xls|Excel 2007(*.xlsx)|*.xlsx|All(*.*)|*.*";
                result = sfd.ShowDialog(this);
            }


            if (result == DialogResult.OK)
            {
                FileInfo info = new FileInfo(sfd.FileName);
                
                if(dt == null)
                    ExportDatagridViewToExcel.Export(DGVQueryResult, sfd.FileName);
                else
                    ExportDatagridViewToExcel.Export(this, dialog, dt, sfd.FileName);
            }
        }

        private void refreshAndExportToExcelToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (IsConnectionSetup())
            {
                Settings conSettings = Settings.LoadSettings(new FileInfo(Application.ExecutablePath).Directory.FullName + @"\ConnectionSettings.stg", "1.0");
                SQLTransaction.CreateTransaction(conSettings["SQLHost"], conSettings["SQLUsername"], conSettings["SQLPassword"], conSettings["SQLInitialCatalog"], new SQLQuery(this, true , Export)).Begin();
            }
            else
                MessageBox.Show(this, "Please configure SQL Connection settings first!", "Query Settings", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
        }



    }
}
