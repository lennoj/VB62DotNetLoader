﻿namespace Portable_Query.Forms
{
    partial class FormMain
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FormMain));
            this.DGVQueryResult = new System.Windows.Forms.DataGridView();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.fileToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.refreshAndExportToExcelToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.refreshToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.exportToExcelToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.exitToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.settingsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.connectionSettginsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.querySettingsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.adminSettingsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.LBLMessage = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.DGVQueryResult)).BeginInit();
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // DGVQueryResult
            // 
            this.DGVQueryResult.AllowUserToAddRows = false;
            this.DGVQueryResult.AllowUserToDeleteRows = false;
            this.DGVQueryResult.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.DGVQueryResult.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.DGVQueryResult.Location = new System.Drawing.Point(19, 43);
            this.DGVQueryResult.Margin = new System.Windows.Forms.Padding(4);
            this.DGVQueryResult.Name = "DGVQueryResult";
            this.DGVQueryResult.ReadOnly = true;
            this.DGVQueryResult.Size = new System.Drawing.Size(1304, 593);
            this.DGVQueryResult.TabIndex = 0;
            this.DGVQueryResult.KeyUp += new System.Windows.Forms.KeyEventHandler(this.DGVQueryResult_KeyUp);
            // 
            // menuStrip1
            // 
            this.menuStrip1.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.fileToolStripMenuItem,
            this.settingsToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Padding = new System.Windows.Forms.Padding(8, 2, 0, 2);
            this.menuStrip1.Size = new System.Drawing.Size(1336, 25);
            this.menuStrip1.TabIndex = 1;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // fileToolStripMenuItem
            // 
            this.fileToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.refreshAndExportToExcelToolStripMenuItem,
            this.refreshToolStripMenuItem,
            this.exportToExcelToolStripMenuItem,
            this.exitToolStripMenuItem});
            this.fileToolStripMenuItem.Name = "fileToolStripMenuItem";
            this.fileToolStripMenuItem.Size = new System.Drawing.Size(39, 21);
            this.fileToolStripMenuItem.Text = "File";
            // 
            // refreshAndExportToExcelToolStripMenuItem
            // 
            this.refreshAndExportToExcelToolStripMenuItem.Image = global::Portable_Query.Properties.Resources.BLOCK_SPINNER_FAST;
            this.refreshAndExportToExcelToolStripMenuItem.Name = "refreshAndExportToExcelToolStripMenuItem";
            this.refreshAndExportToExcelToolStripMenuItem.Size = new System.Drawing.Size(237, 22);
            this.refreshAndExportToExcelToolStripMenuItem.Text = "Refresh and Export to Excel";
            this.refreshAndExportToExcelToolStripMenuItem.Click += new System.EventHandler(this.refreshAndExportToExcelToolStripMenuItem_Click);
            // 
            // refreshToolStripMenuItem
            // 
            this.refreshToolStripMenuItem.Image = global::Portable_Query.Properties.Resources.NEW_REFRESH;
            this.refreshToolStripMenuItem.Name = "refreshToolStripMenuItem";
            this.refreshToolStripMenuItem.Size = new System.Drawing.Size(237, 22);
            this.refreshToolStripMenuItem.Text = "Refresh";
            this.refreshToolStripMenuItem.Click += new System.EventHandler(this.refreshToolStripMenuItem_Click);
            // 
            // exportToExcelToolStripMenuItem
            // 
            this.exportToExcelToolStripMenuItem.Image = global::Portable_Query.Properties.Resources.NEW_EXCEL;
            this.exportToExcelToolStripMenuItem.Name = "exportToExcelToolStripMenuItem";
            this.exportToExcelToolStripMenuItem.Size = new System.Drawing.Size(237, 22);
            this.exportToExcelToolStripMenuItem.Text = "Export to Excel";
            this.exportToExcelToolStripMenuItem.Click += new System.EventHandler(this.exportToExcelToolStripMenuItem_Click);
            // 
            // exitToolStripMenuItem
            // 
            this.exitToolStripMenuItem.Image = global::Portable_Query.Properties.Resources.NEW_LOGOUT;
            this.exitToolStripMenuItem.Name = "exitToolStripMenuItem";
            this.exitToolStripMenuItem.Size = new System.Drawing.Size(237, 22);
            this.exitToolStripMenuItem.Text = "Exit";
            this.exitToolStripMenuItem.Click += new System.EventHandler(this.exitToolStripMenuItem_Click);
            // 
            // settingsToolStripMenuItem
            // 
            this.settingsToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.connectionSettginsToolStripMenuItem,
            this.querySettingsToolStripMenuItem,
            this.adminSettingsToolStripMenuItem});
            this.settingsToolStripMenuItem.Name = "settingsToolStripMenuItem";
            this.settingsToolStripMenuItem.Size = new System.Drawing.Size(66, 21);
            this.settingsToolStripMenuItem.Text = "Settings";
            // 
            // connectionSettginsToolStripMenuItem
            // 
            this.connectionSettginsToolStripMenuItem.Image = global::Portable_Query.Properties.Resources.NEW_DBSETUP;
            this.connectionSettginsToolStripMenuItem.Name = "connectionSettginsToolStripMenuItem";
            this.connectionSettginsToolStripMenuItem.Size = new System.Drawing.Size(205, 22);
            this.connectionSettginsToolStripMenuItem.Text = "Connection Settings";
            this.connectionSettginsToolStripMenuItem.Click += new System.EventHandler(this.connectionSettginsToolStripMenuItem_Click);
            // 
            // querySettingsToolStripMenuItem
            // 
            this.querySettingsToolStripMenuItem.Image = global::Portable_Query.Properties.Resources.NEW_APPLY_CHANGES;
            this.querySettingsToolStripMenuItem.Name = "querySettingsToolStripMenuItem";
            this.querySettingsToolStripMenuItem.Size = new System.Drawing.Size(205, 22);
            this.querySettingsToolStripMenuItem.Text = "Query Settings";
            this.querySettingsToolStripMenuItem.Click += new System.EventHandler(this.querySettingsToolStripMenuItem_Click);
            // 
            // adminSettingsToolStripMenuItem
            // 
            this.adminSettingsToolStripMenuItem.Image = global::Portable_Query.Properties.Resources.NEW_LOGIN;
            this.adminSettingsToolStripMenuItem.Name = "adminSettingsToolStripMenuItem";
            this.adminSettingsToolStripMenuItem.Size = new System.Drawing.Size(205, 22);
            this.adminSettingsToolStripMenuItem.Text = "Administrator Settings";
            this.adminSettingsToolStripMenuItem.Click += new System.EventHandler(this.adminSettingsToolStripMenuItem_Click);
            // 
            // LBLMessage
            // 
            this.LBLMessage.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.LBLMessage.AutoSize = true;
            this.LBLMessage.ForeColor = System.Drawing.Color.White;
            this.LBLMessage.Location = new System.Drawing.Point(16, 649);
            this.LBLMessage.Name = "LBLMessage";
            this.LBLMessage.Size = new System.Drawing.Size(49, 16);
            this.LBLMessage.TabIndex = 13;
            this.LBLMessage.Text = "Ready";
            // 
            // FormMain
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.ClientSize = new System.Drawing.Size(1336, 726);
            this.Controls.Add(this.LBLMessage);
            this.Controls.Add(this.DGVQueryResult);
            this.Controls.Add(this.menuStrip1);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MainMenuStrip = this.menuStrip1;
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "FormMain";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Portable Query";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            ((System.ComponentModel.ISupportInitialize)(this.DGVQueryResult)).EndInit();
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem fileToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem exportToExcelToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem exitToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem settingsToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem connectionSettginsToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem querySettingsToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem adminSettingsToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem refreshToolStripMenuItem;
        public System.Windows.Forms.Label LBLMessage;
        public System.Windows.Forms.DataGridView DGVQueryResult;
        private System.Windows.Forms.ToolStripMenuItem refreshAndExportToExcelToolStripMenuItem;
    }
}