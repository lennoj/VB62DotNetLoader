﻿namespace Portable_Query.Forms
{
    partial class FormQuerySettings
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FormQuerySettings));
            this.BTNSave = new System.Windows.Forms.Button();
            this.BTNTest = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.TXTQuery = new FastColoredTextBoxNS.FastColoredTextBox();
            this.DGVQueryResult = new System.Windows.Forms.DataGridView();
            this.LBLMessage = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.TXTQuery)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.DGVQueryResult)).BeginInit();
            this.SuspendLayout();
            // 
            // BTNSave
            // 
            this.BTNSave.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.BTNSave.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.BTNSave.Location = new System.Drawing.Point(753, 685);
            this.BTNSave.Name = "BTNSave";
            this.BTNSave.Size = new System.Drawing.Size(160, 32);
            this.BTNSave.TabIndex = 9;
            this.BTNSave.Text = "Save";
            this.BTNSave.UseVisualStyleBackColor = true;
            this.BTNSave.Click += new System.EventHandler(this.BTNSave_Click);
            // 
            // BTNTest
            // 
            this.BTNTest.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.BTNTest.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.BTNTest.Location = new System.Drawing.Point(12, 685);
            this.BTNTest.Name = "BTNTest";
            this.BTNTest.Size = new System.Drawing.Size(160, 32);
            this.BTNTest.TabIndex = 8;
            this.BTNTest.Text = "Test";
            this.BTNTest.UseVisualStyleBackColor = true;
            this.BTNTest.Click += new System.EventHandler(this.BTNTest_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(12, 226);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(44, 16);
            this.label2.TabIndex = 6;
            this.label2.Text = "Query";
            // 
            // TXTQuery
            // 
            this.TXTQuery.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.TXTQuery.AutoCompleteBracketsList = new char[] {
        '(',
        ')',
        '{',
        '}',
        '[',
        ']',
        '\"',
        '\"',
        '\'',
        '\''};
            this.TXTQuery.AutoScrollMinSize = new System.Drawing.Size(27, 14);
            this.TXTQuery.BackBrush = null;
            this.TXTQuery.CharHeight = 14;
            this.TXTQuery.CharWidth = 8;
            this.TXTQuery.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.TXTQuery.DisabledColor = System.Drawing.Color.FromArgb(((int)(((byte)(100)))), ((int)(((byte)(180)))), ((int)(((byte)(180)))), ((int)(((byte)(180)))));
            this.TXTQuery.ForeColor = System.Drawing.Color.Black;
            this.TXTQuery.IsReplaceMode = false;
            this.TXTQuery.Location = new System.Drawing.Point(12, 431);
            this.TXTQuery.Name = "TXTQuery";
            this.TXTQuery.Paddings = new System.Windows.Forms.Padding(0);
            this.TXTQuery.SelectionColor = System.Drawing.Color.FromArgb(((int)(((byte)(60)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(255)))));
            this.TXTQuery.ServiceColors = ((FastColoredTextBoxNS.ServiceColors)(resources.GetObject("TXTQuery.ServiceColors")));
            this.TXTQuery.Size = new System.Drawing.Size(901, 237);
            this.TXTQuery.TabIndex = 10;
            this.TXTQuery.Zoom = 100;
            // 
            // DGVQueryResult
            // 
            this.DGVQueryResult.AllowUserToAddRows = false;
            this.DGVQueryResult.AllowUserToDeleteRows = false;
            this.DGVQueryResult.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.DGVQueryResult.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.DGVQueryResult.Location = new System.Drawing.Point(12, 13);
            this.DGVQueryResult.Margin = new System.Windows.Forms.Padding(4);
            this.DGVQueryResult.Name = "DGVQueryResult";
            this.DGVQueryResult.ReadOnly = true;
            this.DGVQueryResult.Size = new System.Drawing.Size(901, 358);
            this.DGVQueryResult.TabIndex = 11;
            // 
            // LBLMessage
            // 
            this.LBLMessage.AutoSize = true;
            this.LBLMessage.Location = new System.Drawing.Point(12, 379);
            this.LBLMessage.Name = "LBLMessage";
            this.LBLMessage.Size = new System.Drawing.Size(49, 16);
            this.LBLMessage.TabIndex = 12;
            this.LBLMessage.Text = "Ready";
            // 
            // FormQuerySettings
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.ClientSize = new System.Drawing.Size(925, 729);
            this.Controls.Add(this.LBLMessage);
            this.Controls.Add(this.DGVQueryResult);
            this.Controls.Add(this.TXTQuery);
            this.Controls.Add(this.BTNSave);
            this.Controls.Add(this.BTNTest);
            this.Controls.Add(this.label2);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ForeColor = System.Drawing.Color.White;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "FormQuerySettings";
            this.ShowInTaskbar = false;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Query Settings";
            ((System.ComponentModel.ISupportInitialize)(this.TXTQuery)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.DGVQueryResult)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button BTNSave;
        private System.Windows.Forms.Button BTNTest;
        private System.Windows.Forms.Label label2;
        public FastColoredTextBoxNS.FastColoredTextBox TXTQuery;
        public System.Windows.Forms.DataGridView DGVQueryResult;
        public System.Windows.Forms.Label LBLMessage;

    }
}