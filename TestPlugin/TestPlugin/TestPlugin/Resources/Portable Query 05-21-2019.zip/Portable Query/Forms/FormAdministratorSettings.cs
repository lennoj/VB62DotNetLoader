﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using Portable_Query.Classes;
using System.IO;

namespace Portable_Query.Forms
{
    public partial class FormAdministratorSettings : Form
    {
        public enum FormType 
        {
            Authenticate,
            SaveSettings
        }

        private FormType FType;
        public FormAdministratorSettings(FormType type)
        {
            InitializeComponent();
            FType = type;

            if (FType == FormType.Authenticate)
            {
                BTNSave.Text = "Login";
                BTNSave.Click += new EventHandler(BTNSave_Click_Login);
            }
            else
            {
                BTNSave.Text = "Save";
                BTNSave.Click += new EventHandler(BTNSave_Click_Save);
            }
        }

        private void BTNSave_Click_Save(object sender, EventArgs e)
        {
            Dictionary<string,string> settings = new Dictionary<string,string>();
            settings.Add("Username", TXTUsername.Text.Trim());
            settings.Add("Password", TXTPassword.Text.Trim());

            Settings.CreateSettings("PQ SETTING", "Administrator Settings", new FileInfo(Application.ExecutablePath).Directory.FullName + @"\UserSettings.stg", "1.0", settings);
            MessageBox.Show(this, "Settings Created!", "Portable Query", MessageBoxButtons.OK, MessageBoxIcon.Information);
            Close();
        }

        private void BTNSave_Click_Login(object sender, EventArgs e)
        {
            Settings settings = Settings.LoadSettings(new FileInfo(Application.ExecutablePath).Directory.FullName + @"\UserSettings.stg", "1.0");


            if (!TXTUsername.Text.Equals(settings["Username"]) || !TXTPassword.Text.Equals(settings["Password"]))
            {
                MessageBox.Show(this, "Incorrect Username or Password" , "Access Denied", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                Close();
            }
            else
            {
                DialogResult = DialogResult.OK;
                Close();
            }
        }





    }
}
