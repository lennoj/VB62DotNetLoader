﻿namespace Portable_Query.Forms
{
    partial class FormConnectionSettings
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FormConnectionSettings));
            this.label1 = new System.Windows.Forms.Label();
            this.TXTUsername = new System.Windows.Forms.TextBox();
            this.TXTPassword = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.BTNTest = new System.Windows.Forms.Button();
            this.BTNSave = new System.Windows.Forms.Button();
            this.TXTInitialCatalog = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.TXTHost = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(16, 62);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(71, 16);
            this.label1.TabIndex = 0;
            this.label1.Text = "Username";
            // 
            // TXTUsername
            // 
            this.TXTUsername.Location = new System.Drawing.Point(132, 59);
            this.TXTUsername.MaxLength = 32;
            this.TXTUsername.Name = "TXTUsername";
            this.TXTUsername.Size = new System.Drawing.Size(315, 22);
            this.TXTUsername.TabIndex = 1;
            // 
            // TXTPassword
            // 
            this.TXTPassword.Location = new System.Drawing.Point(132, 96);
            this.TXTPassword.MaxLength = 32;
            this.TXTPassword.Name = "TXTPassword";
            this.TXTPassword.PasswordChar = '•';
            this.TXTPassword.Size = new System.Drawing.Size(315, 22);
            this.TXTPassword.TabIndex = 2;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(16, 99);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(68, 16);
            this.label2.TabIndex = 2;
            this.label2.Text = "Password";
            // 
            // BTNTest
            // 
            this.BTNTest.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.BTNTest.Location = new System.Drawing.Point(19, 182);
            this.BTNTest.Name = "BTNTest";
            this.BTNTest.Size = new System.Drawing.Size(160, 32);
            this.BTNTest.TabIndex = 4;
            this.BTNTest.Text = "Test";
            this.BTNTest.UseVisualStyleBackColor = true;
            this.BTNTest.Click += new System.EventHandler(this.BTNTest_Click);
            // 
            // BTNSave
            // 
            this.BTNSave.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.BTNSave.Location = new System.Drawing.Point(287, 182);
            this.BTNSave.Name = "BTNSave";
            this.BTNSave.Size = new System.Drawing.Size(160, 32);
            this.BTNSave.TabIndex = 5;
            this.BTNSave.Text = "Save";
            this.BTNSave.UseVisualStyleBackColor = true;
            this.BTNSave.Click += new System.EventHandler(this.BTNSave_Click);
            // 
            // TXTInitialCatalog
            // 
            this.TXTInitialCatalog.Location = new System.Drawing.Point(132, 137);
            this.TXTInitialCatalog.MaxLength = 32;
            this.TXTInitialCatalog.Name = "TXTInitialCatalog";
            this.TXTInitialCatalog.Size = new System.Drawing.Size(315, 22);
            this.TXTInitialCatalog.TabIndex = 3;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(16, 140);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(88, 16);
            this.label3.TabIndex = 6;
            this.label3.Text = "Initial Catalog";
            // 
            // TXTHost
            // 
            this.TXTHost.Location = new System.Drawing.Point(132, 22);
            this.TXTHost.MaxLength = 32;
            this.TXTHost.Name = "TXTHost";
            this.TXTHost.Size = new System.Drawing.Size(315, 22);
            this.TXTHost.TabIndex = 0;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(16, 25);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(36, 16);
            this.label4.TabIndex = 8;
            this.label4.Text = "Host";
            // 
            // FormConnectionSettings
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.ClientSize = new System.Drawing.Size(462, 228);
            this.Controls.Add(this.TXTHost);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.TXTInitialCatalog);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.BTNSave);
            this.Controls.Add(this.BTNTest);
            this.Controls.Add(this.TXTPassword);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.TXTUsername);
            this.Controls.Add(this.label1);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ForeColor = System.Drawing.Color.White;
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "FormConnectionSettings";
            this.ShowInTaskbar = false;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Connection Settings";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button BTNTest;
        private System.Windows.Forms.Button BTNSave;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        public System.Windows.Forms.TextBox TXTUsername;
        public System.Windows.Forms.TextBox TXTPassword;
        public System.Windows.Forms.TextBox TXTInitialCatalog;
        public System.Windows.Forms.TextBox TXTHost;
    }
}