﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data.OleDb;

namespace AlphaList.Classes.SQLTransact
{
    public sealed class Transaction
    {
        private OleDbConnection _Connection;
        private OleDbCommand _Command;
        private ITransaction _Transaction;
        private Exception _Exception;
        

        public OleDbConnection Connection { get { return this._Connection; } }
        public OleDbCommand Command { get { return this._Command; } }
        public Exception LastError { get { return this._Exception; } }

        public Transaction(OleDbConnection connection, ITransaction transaction) 
        {
            this._Connection = connection;
            this._Command = connection == null ? null : connection.CreateCommand();
            this._Transaction = transaction;
        }

        public Transaction(OleDbConnection connection, ITransaction transaction , Exception Error)
        {
            this._Connection = connection;
            this._Command = connection == null ? null : connection.CreateCommand();
            this._Transaction = transaction;
            this._Exception = Error;
        }
    
    
        #region ITransaction Members

        public Transaction Reset() 
        {
            this._Command.Dispose();
            if (this._Connection.State == System.Data.ConnectionState.Closed) 
                this._Connection.Open();

            this._Command = this._Connection.CreateCommand();
            this._Command.CommandText = "";

            return this;
        }

        public Transaction Begin()
        {
            if (this._Connection == null)
                if (this._Transaction != null)
                {
                    this._Transaction.ErrorTransaction(this);
                    return this;
                }

            try
            {
                if (this._Transaction != null)
                {
                    if (this.Connection.State != System.Data.ConnectionState.Open)
                    {
                        this.Connection.Open();
                    }

                    this._Command = this._Connection.CreateCommand();

                    this._Transaction.BeginTransaction(this);
                }

                return this;
            }
            catch (Exception ex)
            {
                if (this._Transaction != null)
                {
                    Console.WriteLine("Transaction::Error >> " + ex.Message);
                    Console.WriteLine("Transaction::StackTrace >> " + ex.StackTrace);
                    
                    this._Exception = ex;
                    this._Transaction.ErrorTransaction(this);
                }

                return this;
            }
        }

        public Transaction Transact()
        {
            if (this._Connection == null)
                if (this._Transaction != null)
                {
                    this._Transaction.ErrorTransaction(this);
                    return this;
                }

            try
            {
                if (this._Transaction != null)
                {
                    if (this.Connection.State != System.Data.ConnectionState.Open)
                    {
                        this.Connection.Open();
                    }
                    this.Command.Connection = this.Connection;

                    this._Transaction.Transact(this);

                    if (this.Connection.State != System.Data.ConnectionState.Open)
                    {
                        this.Connection.Open();
                    }

                    this._Command = this._Connection.CreateCommand();
                    this._Command.Parameters.Clear();
                    
                }

                return this;
            }
            catch (Exception ex)
            {
                if (this._Transaction != null)
                {
                    Console.WriteLine("Transaction::Error >> " + ex.Message);
                    Console.WriteLine("Transaction::StackTrace >> " + ex.StackTrace);
                    
                    this._Exception = ex;
                    this._Transaction.ErrorTransaction(this);
                }

                return this;
            }
        }


        public Transaction  End()
        {
            if (this._Connection == null)
                if (this._Transaction != null)
                {
                    this._Transaction.ErrorTransaction(this);
                    return this;
                }

            try
            {
                if (this._Transaction != null)
                {
                    if (this.Connection.State != System.Data.ConnectionState.Open)
                    {
                        this.Connection.Open();
                    }
                    this._Command = this._Connection.CreateCommand();
                    
                    this._Transaction.EndTransaction(this);

                    this._Connection.Close();
                }
                return this;
            }
            catch (Exception ex)
            {
                if (this._Transaction != null)
                {
                    Console.WriteLine("Transaction::Error >> " + ex.Message);
                    Console.WriteLine("Transaction::StackTrace >> " + ex.StackTrace);
                    
                    this._Exception = ex;
                    this._Transaction.ErrorTransaction(this);
                }

                return this;
            }
        }
        #endregion

    }
}
