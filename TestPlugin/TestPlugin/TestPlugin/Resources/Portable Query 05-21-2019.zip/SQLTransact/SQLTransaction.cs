﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data.OleDb;
using System.Data.SqlClient;
using System.Data.SqlTypes;

namespace AlphaList.Classes.SQLTransact
{
    public abstract class SQLTransaction
    {
        private static string _connectionString;
        public static string ConnectionString { get { return SQLTransaction._connectionString;  } }

        private SQLTransaction(string filePath , string password) 
        {
            
        }

        public static Transaction CreateTransaction(string FilePath, string Password ,ITransaction iTransaction)
        {
            try
            {
                string connectionString = "Provider=Microsoft.Jet.OLEDB.4.0;Data Source=<FILEPATH>;User Id=admin;Jet OLEDB:Database Password=<PASSWORD>;Persist Security Info=False";
                connectionString = connectionString.Replace("<FILEPATH>", FilePath);
                connectionString = connectionString.Replace("<PASSWORD>", Password);
                SQLTransaction._connectionString = connectionString;
                OleDbConnection _NewConnection = new OleDbConnection(connectionString);

                _NewConnection.Open();

                Transaction _NewTransaction = new Transaction(_NewConnection, iTransaction);


                return _NewTransaction;
            }
            catch (Exception ExError)
            {
                Transaction errTran = new Transaction(null, iTransaction, ExError);
                return errTran;
            }

        }

        public static Transaction CreateTransaction(string ConnectionString , ITransaction iTransaction) 
        {
            try
            {
                SQLTransaction._connectionString = ConnectionString;
                OleDbConnection _NewConnection = new OleDbConnection(ConnectionString);
                _NewConnection.Open();

                Transaction _NewTransaction = new Transaction(_NewConnection, iTransaction);


                return _NewTransaction;
            }
            catch (Exception ExError)
            {
                Transaction errTran = new Transaction(null, iTransaction, ExError);
                return errTran;
            }
            
        }

      
    }
}
