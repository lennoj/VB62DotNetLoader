﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data.OleDb;
using System.Data.SqlClient;
using System.Data.SqlTypes;

namespace AlphaList.Classes.SQLTransact
{
    public interface ITransaction
    {
        Transaction BeginTransaction(Transaction transaction);
        Transaction EndTransaction(Transaction transaction);
        Transaction Transact(Transaction transaction);
        Transaction ErrorTransaction(Transaction transaction);
    }
}
